<?php get_header(); ?>

<style>
    <?php include 'CSS/header_style.css'; ?>
</style>

<style>
    <?php include 'CSS/coming-soon_style.css'; ?>
</style>

<div id="mobile-banner">
    <img src="<?php echo get_template_directory_uri(); ?>/IMG/honeysamurai_mobile.png" alt="honeysamurai" id="honeysamurai-mobile">
</div>

<div id="title-box">
    <h1 class="page-heading">Coming Soon!</h1></div>

<main>
    <div class="header-img">
        <img src="<?php echo get_template_directory_uri(); ?>/IMG/alien-monster.png" alt="Alien Monster" id="alien-monster">
    </div> 
</main>
    
    <div class="back-to-top">
        <a href="<?php echo site_url('/coming-soon'); ?>">Back To Top</a>
    </div>

<?php get_footer(); ?> 