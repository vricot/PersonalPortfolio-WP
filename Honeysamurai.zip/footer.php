<footer id="my_footer">
    © 2020 Valerie Ricot, All Rights Reserved
</footer>

<?php wp_footer(); ?>

</body>
</html>