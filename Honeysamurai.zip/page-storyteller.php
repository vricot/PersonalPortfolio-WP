<?php get_header(); ?>

<style>
<?php include 'CSS/header_style.css'; ?>
</style>

<style>
<?php include 'CSS/storyteller_style.css'; ?>
</style>

    <div id="mobile-banner">
        <img src="<?php echo get_template_directory_uri(); ?>/IMG/honeysamurai_mobile.png" alt="honeysamurai" id="honeysamurai-mobile">
    </div>

    <div class="header-img">
        <img src="<?php echo get_template_directory_uri(); ?>/IMG/sailor_saturn_camera_resize_500x367.gif" alt="Sailor Saturn in Camera" id="sailor-saturn">
    </div> 

    <div id="title-box">
    <h1 class="page-heading">Storyteller</h1></div>

<main>
   
    <section>
       <a href="https://www.youtube.com/channel/UCD3CuWR6dw8-4jEMQp-fDIQ" id="youtube-link" target="_blank">
           <div id="portfolio-button" class="button">
               <h3>YouTube/Podcasts</h3>
           </div>
        </a>
        <a href="<?php echo site_url('/coming-soon'); ?>" id="illustration-link">
            <div id="illustration-button"
            class="button">
                <h3>Illustration & Animation</h3>
            </div>
         </a> 
         <a href="<?php echo site_url('/diary'); ?>" id="blog-link">
            <div id="resume-button" class="button" >
                <h3>Blog</h3>
            </div>
         </a> 
         <a href="<?php echo site_url('/contact'); ?>" id="commission-link">
            <div id="commission-button" class="button">
                <h3>Commissions</h3>
            </div>
         </a>
    </section>
</main>
    
    <div class="back-to-top">
        <a href="<?php echo site_url('/storyteller'); ?>">Back To Top</a>
    </div>
        <?php get_footer(); ?>
    
    