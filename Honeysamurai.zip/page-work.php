<?php get_header() ?>

<style>
<?php include 'CSS/header_style.css'; ?>
</style>

<style>
<?php include 'CSS/work_style.css'; ?>
</style>

    </div>
        <div id="mobile-banner">
            <img src="<?php echo get_template_directory_uri(); ?>/IMG/honeysamurai_mobile.png" alt="honeysamurai" id="honeysamurai-mobile">
        </div>
    
    <div id="title-box">
    <h1 class="page-heading">choose your fighter</h1></div>

<main>
    <section>
        <a href="<?php echo site_url('/web-developer'); ?>" id="web-dev-link">
            <div id="web-dev" class="section-div">
                <div class="img-div">
                    <img src="<?php echo get_template_directory_uri(); ?>/IMG/typing_pink_resized_500x367.gif" alt="" id="coding">
                </div>
                <div class="caption-div">
                    <h3>Web Developer</h3>
                </div>
            </div>
        </a>
    
        <a href="<?php echo site_url('/storyteller'); ?>" id="storyteller-link">
            <div id="storyteller" class="section-div">
                <div class="img-div">
                    <img src="<?php echo get_template_directory_uri(); ?>/IMG/sailor_saturn_camera_resize_500x367.gif" alt="" id="sailor-saturn">
                </div>
                <div class="caption-div">
                    <h3>Storyteller</h3>
                </div>
            </div>
        </a>
    
        <a href="<?php echo site_url('/fashion-princess'); ?>" id="fashion-link">
            <div id="fashion" class="section-div">
                <div class="img-div">
                    <img src="<?php echo get_template_directory_uri(); ?>/IMG/fashion_resized_500x367.gif" alt="" id="sailor-makeup">
                </div>
                <div class="caption-div">
                    <h3>Fashion Princess</h3>
                </div>
            </div>
        </a>
    </section>
</main>
    
    <div class="back-to-top">
        <a href="<?php echo site_url('/work'); ?>">Back To Top</a>
    </div>
    

<?php get_footer(); ?>